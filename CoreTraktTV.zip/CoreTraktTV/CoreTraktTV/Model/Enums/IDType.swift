public enum IDType: String {
  case trakt
  case imdb
  case tmdb
  case tvdb
  case tvrage
}

public enum Period: String {
  case weekly
  case monthly
  case yearly
  case all
}

public enum SearchType: String, Codable {
  case movie
  case show
  case episode
  case person
  case list
	case none
}

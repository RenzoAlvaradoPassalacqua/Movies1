public enum HistoryType: String {
  case movies
  case shows
  case seasons
  case episodes
}

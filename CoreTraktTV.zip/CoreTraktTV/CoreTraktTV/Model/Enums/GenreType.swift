public enum GenreType: String {
  case movies
  case shows
}
